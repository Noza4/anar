﻿using Microsoft.AspNetCore.Mvc;
using ProductApp.Dtos;
using ProductApp.Models;
using ProductApp.Services;
using Mapster;

namespace ProductApp.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductController : ControllerBase
{
    private readonly ProductService _service;

    public ProductController(ProductService service) => _service = service;

    [HttpGet]
    public ActionResult<IEnumerable<Product>> GetAll([FromQuery] int page = 1, [FromQuery] int pageSize = 10)
    {
        var products = _service.GetAll()
            .Skip((page - 1) * pageSize)
            .Take(pageSize);
        return Ok(products);
    }

    [HttpGet("{id}")]
    public ActionResult<Product> GetById(Guid id)
    {
        var product = _service.GetById(id);
        return product == null ? NotFound() : Ok(product);
    }

    [HttpPost]
    public ActionResult<Product> Create(ProductCreateDto dto)
    {
        var product = dto.Adapt<Product>();
        _service.Add(product);
        return CreatedAtAction(nameof(GetById), new { id = product.Id }, product);
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(Guid id)
    {
        var product = _service.GetById(id);
        if (product == null) return NotFound();

        _service.Delete(id);
        return NoContent();
    }
}