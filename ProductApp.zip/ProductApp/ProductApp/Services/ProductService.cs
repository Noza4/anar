﻿using ProductApp.Models;

namespace ProductApp.Services;

public class ProductService
{
    private readonly List<Product> _products = new();

    public IEnumerable<Product> GetAll() => _products.OrderBy(p => p.Price);

    public Product? GetById(Guid id) => _products.FirstOrDefault(p => p.Id == id);

    public void Add(Product product) => _products.Add(product);

    public void Delete(Guid id)
    {
        var product = GetById(id);
        if (product != null) _products.Remove(product);
    }
}
